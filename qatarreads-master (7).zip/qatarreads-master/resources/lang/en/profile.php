<?php 
	return [
		'page-title' => "Profile Update",
		'label-1' => 'First Name',
		'label-2' => 'Last Name',
		'label-3' => 'Email',
		'label-4' => 'Contact Number',
		'label-5' => 'Gender',
		'label-6' => 'Nationality',
		'label-7' => 'Type',
		'value-1' => 'Male',
		'value-2' => 'Female',
		'value-3' => 'Are you?',
		'value-4' => 'Parent',
		'value-5' => 'Institution',

		'submit-btn' => 'Update Profile'
	];
<?php 
	return [
		'page-title' => "Subscribe to this Program",
		'page-sub-title-1' => 'Program',
		'table-th-1' => "Program",
		'table-th-2' => "Number Of Elgible Students",
		'table-th-3' => "One Time Cost",
		'table-th-4' => "Monthly Subscription Cost",
		'table-th-5' => "Age Limit",

		'page-sub-title-2' => "Subscriptions",
		'label-1' => 'Address',
		'label-2' => 'State',
		'label-3' => 'City',
		'label-4' => 'Pincode',
		'label-5' => 'Country',
		'label-6' => 'Language',
		'label-7' => 'Apply for Monthly Subscription',

		'submit-btn' => 'Subscribe Now'
	];
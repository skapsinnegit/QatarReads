<?php 
	return [
		'page-title' => "Add Children",
		'label-1' => 'Name',
		'placeholder-1' => 'Child Name',
		'label-2' => 'Date of Birth',
		'label-3' => 'Institution',
		'placeholder-3' => 'Institution Name',
		'label-4' => 'Gender',
		'value-1' => 'Male',
		'value-2' => 'Female',
		'label-5' => 'I agree to the',
		'value-3' => 'Terms and Conditions',

		'submit-btn' => 'Add Child'
	];
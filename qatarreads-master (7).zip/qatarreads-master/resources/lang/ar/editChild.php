<?php 
	return [
		'page-title' => "Edit Children",
		'label-1' => 'Name',
		'label-2' => 'Date of Birth',
		'label-3' => 'Institution',
		'label-4' => 'Gender',
		'value-1' => 'Male',
		'value-2' => 'Female',

		'submit-btn' => 'Update'
	];
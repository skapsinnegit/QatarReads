<?php 
	return [
		'page-title' => "Programs",
		'table-th-1' => "Sl No",
		'table-th-2' => "One Time Setup Cost",
		'table-th-3' => "Monthly Recurring Cost",
		'table-th-4' => "Subscription Status",
		'table-th-5' => "Monthly Subscription",
		'table-th-6' => "Action",
		'table-th-7' => "Age Limit",
		'btn' => 'Subscribe'
	];
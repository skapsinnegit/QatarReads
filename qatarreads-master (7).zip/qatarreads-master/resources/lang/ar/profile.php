<?php 
	return [
		'page-title' => "Profile Update",
		'label-1' => 'الاسم الأول',
		'label-2' => 'الاسم الأخير',
		'label-3' => 'نوع الجنس',
		'label-4' => 'Contact Number',
		'label-5' => 'Gender',
		'label-6' => 'Nationality',
		'label-7' => 'Type',
		'value-1' => 'Male',
		'value-2' => 'Female',
		'value-3' => 'Are you?',
		'value-4' => 'Parent',
		'value-5' => 'Institution',

		'submit-btn' => 'Update Profile'
	];
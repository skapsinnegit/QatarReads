<?php 
	return [
		'page-title' => "Children",
		'sub-title-1' => "My Children",
		'add-child-btn' => "Add Children",
		'child-table-th-1' => "Name",
		'child-table-th-2' => "Date of Birth",
		'child-table-th-3' => "School",
		'child-table-th-4' => "Gender",
		'child-table-th-5' => "Institution",
		'child-table-th-6' => "Action",
		'edit-btn' => 'Edit',
		'delete-btn' => 'Delete'
	];
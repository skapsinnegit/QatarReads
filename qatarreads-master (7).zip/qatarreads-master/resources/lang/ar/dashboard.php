<?php 
	return [
		'page-title' => "Dashboard",
		'sub-title-1' => "My Children",
		'add-child-btn' => "Add Children",
		'child-table-th-1' => "Name",
		'child-table-th-2' => "Date of Birth",
		'child-table-th-3' => "School",
		'child-table-th-4' => "Gender",
		'child-table-th-5' => "Institution",

		'sub-title-2' => "My Subscriptions",
		'subscribe-table-th-1' => "Program Name",
		'subscribe-table-th-2' => "Cost",
	];
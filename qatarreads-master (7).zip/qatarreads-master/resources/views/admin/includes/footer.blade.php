<section class="admin-footer copy-right">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<p class="text-center text-uppercase">Copyright &copy; {{ config('app.name') }} {{ date('Y') }}</p>
			</div>
		</div>
	</div>
</section>